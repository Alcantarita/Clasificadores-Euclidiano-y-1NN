import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score, confusion_matrix
from scipy.spatial import distance

# Cargar el dataset de Pima Indians Diabetes
file_path = 'C:/Users/marco/Downloads/pima-indians-diabetes.csv'
column_names = [
    "pregnancies", "glucose", "blood_pressure", "skin_thickness", "insulin",
    "bmi", "diabetes_pedigree_function", "age", "outcome"
]
data = pd.read_csv(file_path, header=None, names=column_names)

data = data.apply(pd.to_numeric, errors='coerce')

data.dropna(inplace=True)

print(data.head())

X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values

kfold = KFold(n_splits=10, shuffle=True, random_state=42)

accuracies = []
conf_matrices = []

def knn_classifier(X_train, y_train, X_test):
    predictions = []
    for test_point in X_test:
        distances = [distance.euclidean(test_point, train_point) for train_point in X_train]
        nearest_index = np.argmin(distances)
        predictions.append(y_train[nearest_index])
    return np.array(predictions)

for train_index, test_index in kfold.split(X):
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y[train_index], y[test_index]
    
    y_pred = knn_classifier(X_train, y_train, X_test)
    
    accuracy = accuracy_score(y_test, y_pred)
    accuracies.append(accuracy)
    
    conf_matrix = confusion_matrix(y_test, y_pred)
    conf_matrices.append(conf_matrix)

average_accuracy = np.mean(accuracies)
print(f"Accuracy promedio en 10 folds: {average_accuracy:.2f}")

total_conf_matrix = np.sum(conf_matrices, axis=0)
print("Matriz de Confusión total:")
print(total_conf_matrix)
