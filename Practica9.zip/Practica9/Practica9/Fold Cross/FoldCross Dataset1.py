import numpy as np
import pandas as pd
from sklearn.model_selection import KFold       # Libreria para implementación de K Fold Cross 
from sklearn.metrics import accuracy_score, confusion_matrix
from scipy.spatial import distance

file_path = 'C:/Users/marco/Downloads/iris/iris.data'

column_names = ["sepal_length", "sepal_width", "petal_length", "petal_width", "class"]
data = pd.read_csv(file_path, header=None, names=column_names)

data.dropna(inplace=True)

X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values

def knn_classifier(X_train, y_train, X_test):
    predictions = []
    for test_point in X_test:
        distances = [distance.euclidean(test_point, train_point) for train_point in X_train]
        nearest_index = np.argmin(distances)
        predictions.append(y_train[nearest_index])
    return np.array(predictions)

# Implementación de K-Fold Cross Validation con K=10
kfold = KFold(n_splits=10, shuffle=True, random_state=42)  # Dividir en 10 partes, mezcla aleatoria y reproducibilidad

# Variables para almacenar los resultados de cada fold
accuracies = []     #Lista para almacenar los acurracies de cada fold 
conf_matrices = []  #Lista par almacenar la matriz de confusión de cada fold 

for train_index, test_index in kfold.split(X):  #Proceso de entrenamiento y prueba, devuelve indices de entranmiento y validación en cada iteración
    # Dividir el dataset en conjunto de entrenamiento y prueba según los índices de K Fold
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y[train_index], y[test_index]
    
    # Predecir las etiquetas en el conjunto de prueba usando 1-NN
    y_pred = knn_classifier(X_train, y_train, X_test)
    
    # Calcular el Accuracy y la matriz de confusión para el fold iterado y guardar en la lista correspondiente
    accuracy = accuracy_score(y_test, y_pred)
    accuracies.append(accuracy)
    
    conf_matrix = confusion_matrix(y_test, y_pred)
    conf_matrices.append(conf_matrix)

# Cálculo del accuracy promedio
mean_accuracy = np.mean(accuracies)
print(f"Accuracy promedio en 10 folds: {mean_accuracy:.2f}")

# Matriz de confusión general 
total_conf_matrix = np.sum(conf_matrices, axis=0)
print("Matriz de Confusión total:")
print(total_conf_matrix)
